## Android Integrated Document

### Integration options

Supports:
ARMv7 and ARMv8 architectures;
Android system 4.3+

#### SDK install
(1).Add the CastarSdk.aar file to your project,put it into App module's libs directory.

(2).Implementation sdk in your app module's build.gradle file.

```kotlin
  dependencies {
        implementation(files("libs/CastarSdk.aar"))
    }
```

(3).Add internet permission in your app module's AndroidManifest.xml file.

```kotlin
<uses-permission android:name="android.permission.INTERNET" />
```

(4).Create your Application, init sdk and start it.

```kotlin
  //Example:Your CliendId is "CSK****FHQlUQZ"
import android.app.Application
    import com.castarsdk.android.CastarSdk
        
    class MyApplication:Application() {

                override fun onCreate() {
                    super.onCreate()
                
                    //set your ClientId and start sdk.
                    CastarSdk.Start(this,"CSK****FHQlUQZ")
                }
                
            }
            
```
(5).Declare your application in your AndroidManifest.xml file.
```kotlin
 <application
        android:icon="@mipmap/ic_launcher"
        android:label="demo"
        android:name=".MyApplication"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Test2"
        tools:targetApi="31">

 </application>
```



#### Optional APIs

##### Start service
CastarSdk.start()

##### Stop service
CastarSdk.Stop()
